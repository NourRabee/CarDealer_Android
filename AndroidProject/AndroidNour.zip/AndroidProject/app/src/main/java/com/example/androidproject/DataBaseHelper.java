package com.example.androidproject;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBaseHelper extends SQLiteOpenHelper {

    public DataBaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("CREATE TABLE CAR(" +
                "ID INTEGER PRIMARY KEY UNIQUE," +
                "MAKE TEXT," +
                "MODEL TEXT," +
                "TYPE TEXT," +
                "PRICE INTEGER," +
                "YEAR TEXT," +
                "COLOR TEXT," +
                "FUEL_TYPE TEXT," +
                "TRANSMISSION_TYPE TEXT," +
                "ENGINE_TYPE_SIZE TEXT," +
                "HORSEPOWER INTEGER," +
                "SEATING_CAPACITY INTEGER," +
                "FEATURES TEXT," +
                "DESCRIPTION TEXT)");

        sqLiteDatabase.execSQL("CREATE TABLE RESERVE" +
                "(EMAIL TEXT, " +
                "CARID INTEGER," +
                " DATE TEXT)");

        sqLiteDatabase.execSQL("CREATE TABLE FAVORITE(" +
                "EMAIL TEXT, " +
                "CARID INTEGER)");

        sqLiteDatabase.execSQL("CREATE TABLE USER(" +
                "EMAIL TEXT PRIMARY KEY," +
                "FIRSTNAME TEXT," +
                "LASTNAME TEXT, " +
                "HASHED_PASSWORD TEXT," +
                "GENDER TEXT," +
                "PHONENUMBER TEXT," +
                "COUNTRY TEXT," +
                "CITY TEXT," +
                "isAdmin INTEGER)");


        sqLiteDatabase.execSQL("INSERT INTO USER(EMAIL, FIRSTNAME, LASTNAME, HASHED_PASSWORD, GENDER, PHONENUMBER, COUNTRY, CITY, isAdmin)" +
                " VALUES ('nour@gmail.com', 'Nour', 'Rabee', 'nour', 'Female', '059', 'Palestine', 'Ramallah', 1)");

        sqLiteDatabase.execSQL("INSERT INTO USER(EMAIL, FIRSTNAME, LASTNAME, HASHED_PASSWORD, GENDER, PHONENUMBER, COUNTRY, CITY, isAdmin)" +
                " VALUES ('najwa@gmail.com', 'Najwa', 'Bsharat', 'najwa', 'Female', '059', 'Palestine', 'Ramallah', 0)");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertUser(User user) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("EMAIL", user.getEmail());
        contentValues.put("FIRSTNAME", user.getFirstName());
        contentValues.put("LASTNAME", user.getLastName());
        contentValues.put("HASHED_PASSWORD", user.getPassword());
        contentValues.put("GENDER", user.getGender());
        contentValues.put("PHONENUMBER", user.getPhoneNumber());
        contentValues.put("CITY", user.getCity());
        contentValues.put("COUNTRY", user.getCountry());
        contentValues.put("isAdmin", user.isAdmin());
        sqLiteDatabase.insert("USER", null, contentValues);

        sqLiteDatabase.close();
    }


    public void insertAdmin(String email, String firstName, String lastName, String password, String gender, String phoneNumber, String city, String country) {

        ContentValues contentValues = new ContentValues();
        contentValues.put("EMAIL", email);
        contentValues.put("FIRSTNAME", firstName);
        contentValues.put("LASTNAME", lastName);
        contentValues.put("PASSWORD", password);
        contentValues.put("GENDER", gender);
        contentValues.put("PHONENUMBER", phoneNumber);
        contentValues.put("CITY", city);
        contentValues.put("COUNTRY", country);
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        sqLiteDatabase.insert("ADMIN", null, contentValues);
    }
//
//    public Boolean insertData(String email, String password) {
//
//        SQLiteDatabase MyDatabase = this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//        contentValues.put("email", email);
//        contentValues.put("password", password);
//        long result = MyDatabase.insert("users", null, contentValues);
//        if (result == -1) {
//            return false;
//        } else {
//            return true;
//        }
//    }
//    public Boolean checkEmail(String email) {
//        SQLiteDatabase MyDatabase = this.getWritableDatabase();
//        Cursor cursor = MyDatabase.rawQuery("Select * from users where email = ?", new String[]{email});
//        if (cursor.getCount() > 0) {
//            return true;
//        } else {
//            return false;
//        }
//    }

    @SuppressLint("Range")
    public User getUser(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        User user = null;

        String[] projection = {
                "EMAIL",
                "FIRSTNAME",
                "LASTNAME",
                "HASHED_PASSWORD",
                "GENDER",
                "PHONENUMBER",
                "COUNTRY",
                "CITY",
                "isAdmin"
        };

        String selection = "EMAIL=?";
        String[] selectionArgs = {email};

        Cursor cursor = db.query("USER", projection, selection, selectionArgs, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            user = new User();
            user.setEmail(cursor.getString(cursor.getColumnIndex("EMAIL")));
            user.setFirstName(cursor.getString(cursor.getColumnIndex("FIRSTNAME")));
            user.setLastName(cursor.getString(cursor.getColumnIndex("LASTNAME")));
            user.setPassword(cursor.getString(cursor.getColumnIndex("HASHED_PASSWORD")));
            user.setGender(cursor.getString(cursor.getColumnIndex("GENDER")));
            user.setPhoneNumber(cursor.getString(cursor.getColumnIndex("PHONENUMBER")));
            user.setCountry(cursor.getString(cursor.getColumnIndex("COUNTRY")));
            user.setCity(cursor.getString(cursor.getColumnIndex("CITY")));
            user.setAdmin(cursor.getInt(cursor.getColumnIndex("isAdmin")));

            cursor.close();
        }

        db.close();

        return user;
    }

}

