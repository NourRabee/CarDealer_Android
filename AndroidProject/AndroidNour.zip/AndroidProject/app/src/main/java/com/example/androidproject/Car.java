package com.example.androidproject;

public class Car {
    private int id;
    private String type;

    public Car() {
    }

    public Car(int id, String type) {
        this.id = id;
        this.type = type;
    }

    public int getID() {
        return id;
    }

    public void setID(int ID) {
        this.id = ID;
    }

    public String getName() {
        return type;
    }

    public void setName(String name) {
        this.type = name;
    }

    @Override
    public String toString() {
        return "Car{" + "\nid= " + id + "\ntype= " + type + '\n' + '}' + '\n';
    }
}